import React, {Fragment} from 'react';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import Button from 'react-bootstrap/Button';
import { workflowVar } from '../apollo/reactiveVars';
import { useReactiveVar } from '@apollo/client';
import {BasicDetailsForm} from './form1';
import {ExtraDataForm} from './form2';
import { Container } from 'react-bootstrap';
import { NavBar } from './Navbar';

function Index() {
    const workflow = useReactiveVar(workflowVar);
    const updateFirstWorflow = () => {
        workflowVar(1);
    }
    const updateSecondWorflow = () => {
        workflowVar(2);
    }
    const updateThirdWorflow = () => {
        workflowVar(3);
    }
  return (
      <Fragment>  
          <NavBar/>
          <Container>
            {
                workflow === 1 
                ?
                <BasicDetailsForm />
                :
                <ExtraDataForm />
            }
        </Container>  
            
      </Fragment>

  );
}

export {Index};
