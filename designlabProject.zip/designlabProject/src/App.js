import './App.css';
import React from 'react';
import { Index } from './components';

function App() {
  return (
    <div className="App">
      <Index />
    </div>
  );
}

export default App;
